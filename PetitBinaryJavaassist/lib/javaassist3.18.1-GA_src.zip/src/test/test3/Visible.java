package test3;

class Visible2 {
    public int pub;
    protected int pro;
    private int pri;
    int pack;
}

public class Visible {
    public int pub;
    protected int pro;
    private int pri;
    int pack;
}
