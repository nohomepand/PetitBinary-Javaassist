package testproxy;

public class Target5 {
    private int value;
    public Target5(int i) { value = i; }
    public int get() { return value; }
}
