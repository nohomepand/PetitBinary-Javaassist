package testproxy.sub;

public class TargetSuper {
    private int poi() { return 1; }
    int poi2() { return 2; }
    public int poi3() { return 3; }
}
