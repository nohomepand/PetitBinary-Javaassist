package testproxy;

public class Target1 {
    public Target1[][] m(Target1[][] a) { return a; }
}
