package test1;

public class Freeze {
}
