package test2;

public interface SuperInterface1 {
    public int getAge();
    public int setAge(int value);
}
